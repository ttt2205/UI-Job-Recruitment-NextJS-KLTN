'use client';

import { useState, useEffect } from 'react';
import {
    Plus,
    Search,
    Filter,
    Edit2,
    Trash2,
    Eye,
    X,
    Check,
    DollarSign,
    Clock,
    Tag,
    FileText,
    Package,
    TrendingUp,
    Zap,
    Star,
    ChevronDown,
} from 'lucide-react';

export default function ServicesPage() {
    const [services, setServices] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [filterStatus, setFilterStatus] = useState('all');
    const [filterCategory, setFilterCategory] = useState('all');
    const [showModal, setShowModal] = useState(false);
    const [showDetailModal, setShowDetailModal] = useState(false);
    const [modalMode, setModalMode] = useState('add');
    const [selectedService, setSelectedService] = useState(null);
    const [viewMode, setViewMode] = useState('grid'); // 'grid' or 'table'
    const [formData, setFormData] = useState({
        name: '',
        description: '',
        price: '',
        durationDay: '',
        isLifetime: false,
        jobPostLimit: '',
        highlightJobLimit: '',
    });

    // Fetch services from API
    useEffect(() => {
        fetchServices();
    }, []);

    const fetchServices = async () => {
        try {
            setLoading(true);
            const response = await fetch('http://localhost:3000/api/v1/employer-packages', {
                method: 'GET',
                credentials: 'include',
                headers: {
                    'Content-Type': 'application/json',
                }
            });
            
            if (!response.ok) {
                throw new Error('Failed to fetch services');
            }

            const data = await response.json();
            
            const transformedData = data.results?.map(item => ({
                id: item.id,
                name: item.name,
                category: 'Gói dịch vụ',
                price: item.price,
                duration: item.isLifetime ? 'Vĩnh viễn' : item.durationDay,
                description: item.description,
                features: [
                    `${item.jobPostLimit} tin tuyển dụng`,
                    `${item.highlightJobLimit} tin nổi bật`,
                    item.isLifetime ? 'Không giới hạn thời gian' : `${item.durationDay} ngày sử dụng`
                ],
                status: 'active',
                orders: Math.floor(Math.random() * 100),
                isLifetime: item.isLifetime,
                jobPostLimit: item.jobPostLimit,
                highlightJobLimit: item.highlightJobLimit,
            })) || [];

            setServices(transformedData);
        } catch (error) {
            console.error('Error fetching services:', error);
            alert('Không thể tải danh sách dịch vụ');
        } finally {
            setLoading(false);
        }
    };

    const filteredServices = services.filter((service) => {
        const matchSearch = service.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            service.description.toLowerCase().includes(searchTerm.toLowerCase());
        const matchStatus = filterStatus === 'all' || service.status === filterStatus;
        const matchCategory = filterCategory === 'all' || service.category === filterCategory;
        return matchSearch && matchStatus && matchCategory;
    });

    const handleAddService = () => {
        setModalMode('add');
        setFormData({
            name: '',
            description: '',
            price: '',
            durationDay: '',
            isLifetime: false,
            jobPostLimit: '',
            highlightJobLimit: '',
        });
        setShowModal(true);
    };

    const handleEditService = (service) => {
        setModalMode('edit');
        setSelectedService(service);
        setFormData({
            name: service.name,
            description: service.description,
            price: service.price,
            durationDay: service.isLifetime ? '' : service.duration,
            isLifetime: service.isLifetime,
            jobPostLimit: service.jobPostLimit,
            highlightJobLimit: service.highlightJobLimit,
        });
        setShowModal(true);
    };

    const handleViewService = (service) => {
        setSelectedService(service);
        setShowDetailModal(true);
    };

    const handleDeleteService = async (id) => {
        if (!confirm('Bạn có chắc chắn muốn xóa dịch vụ này?')) {
            return;
        }

        try {
            const response = await fetch(`http://localhost:3000/api/v1/employer-packages/${id}`, {
                method: 'DELETE',
                credentials: 'include',
            });

            if (!response.ok) {
                throw new Error('Failed to delete service');
            }

            await fetchServices();
            alert('Xóa dịch vụ thành công!');
        } catch (error) {
            console.error('Error deleting service:', error);
            alert('Không thể xóa dịch vụ');
        }
    };

    const handleSubmit = async () => {
        if (!formData.name || !formData.price || !formData.description) {
            alert('Vui lòng điền đầy đủ thông tin bắt buộc!');
            return;
        }

        if (!formData.isLifetime && !formData.durationDay) {
            alert('Vui lòng nhập thời hạn hoặc chọn gói vĩnh viễn!');
            return;
        }

        if (!formData.jobPostLimit || !formData.highlightJobLimit) {
            alert('Vui lòng nhập giới hạn tin đăng và tin nổi bật!');
            return;
        }

        try {
            const requestData = {
                name: formData.name,
                description: formData.description,
                price: Number(formData.price),
                durationDay: formData.isLifetime ? null : Number(formData.durationDay),
                isLifetime: formData.isLifetime,
                jobPostLimit: Number(formData.jobPostLimit),
                highlightJobLimit: Number(formData.highlightJobLimit),
            };

            const url = modalMode === 'add' 
                ? 'http://localhost:3000/api/v1/employer-packages'
                : `http://localhost:3000/api/v1/employer-packages/${selectedService.id}`;

            const method = modalMode === 'add' ? 'POST' : 'PATCH';

            const response = await fetch(url, {
                method: method,
                credentials: 'include',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(requestData),
            });

            if (!response.ok) {
                throw new Error(`Failed to ${modalMode} service`);
            }

            await fetchServices();
            setShowModal(false);
            alert(`${modalMode === 'add' ? 'Thêm' : 'Cập nhật'} dịch vụ thành công!`);
        } catch (error) {
            console.error(`Error ${modalMode} service:`, error);
            alert(`Không thể ${modalMode === 'add' ? 'thêm' : 'cập nhật'} dịch vụ`);
        }
    };

    const formatCurrency = (amount) => {
        return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(amount);
    };

    const stats = {
        total: services.length,
        active: services.filter((s) => s.status === 'active').length,
        inactive: services.filter((s) => s.status === 'inactive').length,
        totalRevenue: services.reduce((sum, s) => sum + (s.price * s.orders), 0),
    };

    if (loading) {
        return (
            <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
                <div className="text-center">
                    <div className="relative">
                        <div className="animate-spin rounded-full h-16 w-16 border-4 border-blue-200 mx-auto"></div>
                        <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-blue-600 absolute top-0 left-1/2 -translate-x-1/2"></div>
                    </div>
                    <p className="mt-6 text-gray-600 font-medium">Đang tải dữ liệu...</p>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 p-6">
            <div className="max-w-7xl mx-auto">
                {/* Header */}
                <div className="mb-8">
                    <h1 className="text-4xl font-bold text-gray-900 mb-2 flex items-center gap-3">
                        <Package className="text-blue-600" size={36} />
                        Quản lý dịch vụ
                    </h1>
                    <p className="text-gray-600">Quản lý các gói dịch vụ dành cho nhà tuyển dụng</p>
                </div>

                {/* Statistics Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                    <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl shadow-lg p-6 text-white transform hover:scale-105 transition-transform duration-200">
                        <div className="flex items-center justify-between mb-4">
                            <div className="bg-white/20 backdrop-blur-sm p-3 rounded-xl">
                                <Package size={28} />
                            </div>
                            <TrendingUp size={24} className="opacity-60" />
                        </div>
                        <p className="text-blue-100 text-sm font-medium mb-1">Tổng dịch vụ</p>
                        <p className="text-4xl font-bold">{stats.total}</p>
                    </div>

                    <div className="bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl shadow-lg p-6 text-white transform hover:scale-105 transition-transform duration-200">
                        <div className="flex items-center justify-between mb-4">
                            <div className="bg-white/20 backdrop-blur-sm p-3 rounded-xl">
                                <Check size={28} />
                            </div>
                            <Zap size={24} className="opacity-60" />
                        </div>
                        <p className="text-green-100 text-sm font-medium mb-1">Đang hoạt động</p>
                        <p className="text-4xl font-bold">{stats.active}</p>
                    </div>

                    <div className="bg-gradient-to-br from-red-500 to-pink-600 rounded-2xl shadow-lg p-6 text-white transform hover:scale-105 transition-transform duration-200">
                        <div className="flex items-center justify-between mb-4">
                            <div className="bg-white/20 backdrop-blur-sm p-3 rounded-xl">
                                <X size={28} />
                            </div>
                        </div>
                        <p className="text-red-100 text-sm font-medium mb-1">Ngừng hoạt động</p>
                        <p className="text-4xl font-bold">{stats.inactive}</p>
                    </div>

                    <div className="bg-gradient-to-br from-purple-500 to-indigo-600 rounded-2xl shadow-lg p-6 text-white transform hover:scale-105 transition-transform duration-200">
                        <div className="flex items-center justify-between mb-4">
                            <div className="bg-white/20 backdrop-blur-sm p-3 rounded-xl">
                                <DollarSign size={28} />
                            </div>
                            <Star size={24} className="opacity-60" />
                        </div>
                        <p className="text-purple-100 text-sm font-medium mb-1">Doanh thu ước tính</p>
                        <p className="text-2xl font-bold">{formatCurrency(stats.totalRevenue)}</p>
                    </div>
                </div>

                {/* Filters and Actions */}
                <div className="bg-white rounded-2xl shadow-lg p-6 mb-8 border border-gray-100">
                    <div className="flex flex-col lg:flex-row gap-4 items-center justify-between">
                        <div className="flex-1 flex flex-col sm:flex-row gap-3 w-full">
                            <div className="relative flex-1">
                                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                                <input
                                    type="text"
                                    placeholder="Tìm kiếm dịch vụ..."
                                    className="w-full pl-12 pr-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                />
                            </div>
                            <div className="relative">
                                <Filter className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                                <select
                                    className="appearance-none pl-12 pr-10 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all bg-white cursor-pointer"
                                    value={filterStatus}
                                    onChange={(e) => setFilterStatus(e.target.value)}
                                >
                                    <option value="all">Tất cả trạng thái</option>
                                    <option value="active">Hoạt động</option>
                                    <option value="inactive">Ngừng hoạt động</option>
                                </select>
                                <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 pointer-events-none" size={20} />
                            </div>
                        </div>
                        <button
                            onClick={handleAddService}
                            className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-6 py-3 rounded-xl hover:from-blue-700 hover:to-indigo-700 flex items-center gap-2 whitespace-nowrap shadow-lg hover:shadow-xl transition-all transform hover:scale-105 font-medium"
                        >
                            <Plus size={20} />
                            Thêm dịch vụ
                        </button>
                    </div>
                </div>

                {/* Services Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredServices.map((service) => (
                        <div 
                            key={service.id} 
                            className="bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden border border-gray-100 transform hover:-translate-y-2"
                        >
                            {/* Card Header */}
                            <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-6 text-white">
                                <div className="flex items-start justify-between mb-4">
                                    <div className="bg-white/20 backdrop-blur-sm p-3 rounded-xl">
                                        <Package size={28} />
                                    </div>
                                    <span className={`px-3 py-1 text-xs font-semibold rounded-full ${
                                        service.status === 'active'
                                            ? 'bg-green-400 text-green-900'
                                            : 'bg-red-400 text-red-900'
                                    }`}>
                                        {service.status === 'active' ? 'Hoạt động' : 'Ngừng'}
                                    </span>
                                </div>
                                <h3 className="text-2xl font-bold mb-2">{service.name}</h3>
                                <div className="flex items-baseline gap-2">
                                    <span className="text-3xl font-bold">{formatCurrency(service.price)}</span>
                                    <span className="text-blue-200 text-sm">
                                        / {service.isLifetime ? 'Vĩnh viễn' : `${service.duration} ngày`}
                                    </span>
                                </div>
                            </div>

                            {/* Card Body */}
                            <div className="p-6">
                                <p className="text-gray-600 text-sm mb-6 line-clamp-2">{service.description}</p>

                                {/* Features */}
                                <div className="space-y-3 mb-6">
                                    {service.features.map((feature, index) => (
                                        <div key={index} className="flex items-start gap-3">
                                            <div className="bg-green-100 p-1 rounded-full mt-0.5">
                                                <Check size={14} className="text-green-600" />
                                            </div>
                                            <span className="text-gray-700 text-sm flex-1">{feature}</span>
                                        </div>
                                    ))}
                                </div>

                                {/* Stats */}
                                <div className="grid grid-cols-2 gap-4 mb-6 p-4 bg-gray-50 rounded-xl">
                                    <div>
                                        <div className="flex items-center gap-2 text-gray-600 mb-1">
                                            <FileText size={16} />
                                            <span className="text-xs">Tin đăng</span>
                                        </div>
                                        <p className="text-lg font-bold text-gray-900">{service.jobPostLimit}</p>
                                    </div>
                                    <div>
                                        <div className="flex items-center gap-2 text-gray-600 mb-1">
                                            <Star size={16} />
                                            <span className="text-xs">Tin nổi bật</span>
                                        </div>
                                        <p className="text-lg font-bold text-gray-900">{service.highlightJobLimit}</p>
                                    </div>
                                </div>

                                {/* Actions */}
                                <div className="flex gap-2">
                                    <button
                                        onClick={() => handleViewService(service)}
                                        className="flex-1 py-2.5 text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-xl font-medium transition-colors flex items-center justify-center gap-2"
                                        title="Xem chi tiết"
                                    >
                                        <Eye size={18} />
                                        Xem
                                    </button>
                                    <button
                                        onClick={() => handleEditService(service)}
                                        className="flex-1 py-2.5 text-green-600 bg-green-50 hover:bg-green-100 rounded-xl font-medium transition-colors flex items-center justify-center gap-2"
                                        title="Chỉnh sửa"
                                    >
                                        <Edit2 size={18} />
                                        Sửa
                                    </button>
                                    <button
                                        onClick={() => handleDeleteService(service.id)}
                                        className="p-2.5 text-red-600 bg-red-50 hover:bg-red-100 rounded-xl transition-colors"
                                        title="Xóa"
                                    >
                                        <Trash2 size={18} />
                                    </button>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>

                {filteredServices.length === 0 && (
                    <div className="text-center py-16 bg-white rounded-2xl shadow-lg">
                        <Package size={64} className="text-gray-300 mx-auto mb-4" />
                        <p className="text-gray-500 text-lg">Không tìm thấy dịch vụ nào</p>
                    </div>
                )}
            </div>

            {/* Add/Edit Modal */}
            {showModal && (
                <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fadeIn">
                    <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl animate-slideUp">
                        <div className="sticky top-0 bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-6 py-4 flex items-center justify-between rounded-t-2xl">
                            <h3 className="text-xl font-bold">
                                {modalMode === 'add' ? 'Thêm dịch vụ mới' : 'Chỉnh sửa dịch vụ'}
                            </h3>
                            <button
                                onClick={() => setShowModal(false)}
                                className="text-white/80 hover:text-white hover:bg-white/20 p-2 rounded-lg transition-colors"
                            >
                                <X size={24} />
                            </button>
                        </div>
                        <div className="p-6 space-y-5">
                            <div>
                                <label className="block text-sm font-semibold text-gray-700 mb-2">
                                    Tên gói dịch vụ *
                                </label>
                                <input
                                    type="text"
                                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                                    placeholder="Nhập tên gói dịch vụ"
                                    value={formData.name}
                                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                                />
                            </div>

                            <div>
                                <label className="block text-sm font-semibold text-gray-700 mb-2">
                                    Mô tả *
                                </label>
                                <textarea
                                    rows="3"
                                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all resize-none"
                                    placeholder="Nhập mô tả chi tiết"
                                    value={formData.description}
                                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                                />
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                                        Giá (VNĐ) *
                                    </label>
                                    <div className="relative">
                                        <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                                        <input
                                            type="number"
                                            min="0"
                                            className="w-full pl-10 pr-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                                            placeholder="0"
                                            value={formData.price}
                                            onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                                        />
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                                        Thời hạn (ngày)
                                    </label>
                                    <div className="relative">
                                        <Clock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                                        <input
                                            type="number"
                                            min="1"
                                            disabled={formData.isLifetime}
                                            className="w-full pl-10 pr-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all disabled:bg-gray-100 disabled:cursor-not-allowed"
                                            placeholder="0"
                                            value={formData.durationDay}
                                            onChange={(e) => setFormData({ ...formData, durationDay: e.target.value })}
                                        />
                                    </div>
                                </div>
                            </div>

                            <div className="bg-blue-50 border-2 border-blue-200 rounded-xl p-4">
                                <label className="flex items-center cursor-pointer">
                                    <input
                                        type="checkbox"
                                        className="w-5 h-5 text-blue-600 rounded focus:ring-blue-500 cursor-pointer"
                                        checked={formData.isLifetime}
                                        onChange={(e) => setFormData({ ...formData, isLifetime: e.target.checked, durationDay: '' })}
                                    />
                                    <span className="ml-3 text-sm font-medium text-gray-700">
                                        Gói vĩnh viễn (không giới hạn thời gian)
                                    </span>
                                </label>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                                        Số tin đăng *
                                    </label>
                                    <div className="relative">
                                        <FileText className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                                        <input
                                            type="number"
                                            min="0"
                                            className="w-full pl-10 pr-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                                            placeholder="0"
                                            value={formData.jobPostLimit}
                                            onChange={(e) => setFormData({ ...formData, jobPostLimit: e.target.value })}
                                        />
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                                        Số tin nổi bật *
                                    </label>
                                    <div className="relative">
                                        <Star className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                                        <input
                                            type="number"
                                            min="0"
                                            className="w-full pl-10 pr-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                                            placeholder="0"
                                            value={formData.highlightJobLimit}
                                            onChange={(e) => setFormData({ ...formData, highlightJobLimit: e.target.value })}
                                        />
                                    </div>
                                </div>
                            </div>

                            <div className="flex gap-3 pt-4">
                                <button
                                    onClick={() => setShowModal(false)}
                                    className="flex-1 px-4 py-3 border-2 border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 font-medium transition-colors"
                                >
                                    Hủy
                                </button>
                                <button
                                    onClick={handleSubmit}
                                    className="flex-1 px-4 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl hover:from-blue-700 hover:to-indigo-700 font-medium transition-all shadow-lg hover:shadow-xl"
                                >
                                    {modalMode === 'add' ? 'Thêm mới' : 'Cập nhật'}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* Detail Modal */}
            {showDetailModal && selectedService && (
                <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fadeIn">
                    <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl animate-slideUp">
                        <div className="sticky top-0 bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-6 py-4 flex items-center justify-between rounded-t-2xl">
                            <h3 className="text-xl font-bold">Chi tiết dịch vụ</h3>
                            <button
                                onClick={() => setShowDetailModal(false)}
                                className="text-white/80 hover:text-white hover:bg-white/20 p-2 rounded-lg transition-colors"
                            >
                                <X size={24} />
                            </button>
                        </div>
                        <div className="p-6 space-y-6">
                            {/* Service Header */}
                            <div className="text-center pb-6 border-b border-gray-200">
                                <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl mb-4 shadow-lg">
                                    <Package size={40} className="text-white" />
                                </div>
                                <h4 className="text-3xl font-bold text-gray-900 mb-3">{selectedService.name}</h4>
                                <span className={`inline-block px-4 py-2 text-sm font-semibold rounded-full ${
                                    selectedService.status === 'active'
                                        ? 'bg-green-100 text-green-800'
                                        : 'bg-red-100 text-red-800'
                                }`}>
                                    {selectedService.status === 'active' ? 'Hoạt động' : 'Ngừng hoạt động'}
                                </span>
                            </div>

                            {/* Price Card */}
                            <div className="bg-gradient-to-br from-blue-600 to-indigo-600 rounded-2xl p-6 text-white text-center shadow-lg">
                                <p className="text-blue-100 text-sm mb-2">Giá gói dịch vụ</p>
                                <div className="flex items-baseline justify-center gap-2 mb-2">
                                    <span className="text-4xl font-bold">{formatCurrency(selectedService.price)}</span>
                                </div>
                                <div className="flex items-center justify-center gap-2 text-blue-100">
                                    <Clock size={18} />
                                    <span className="text-sm">
                                        {selectedService.isLifetime ? 'Vĩnh viễn' : `${selectedService.duration} ngày sử dụng`}
                                    </span>
                                </div>
                            </div>

                            {/* Stats Grid */}
                            <div className="grid grid-cols-2 gap-4">
                                <div className="bg-gradient-to-br from-green-50 to-emerald-50 p-5 rounded-xl border-2 border-green-200">
                                    <div className="flex items-center gap-3 mb-2">
                                        <div className="bg-green-500 p-2 rounded-lg">
                                            <FileText size={20} className="text-white" />
                                        </div>
                                        <span className="text-sm font-medium text-gray-700">Tin đăng tuyển</span>
                                    </div>
                                    <p className="text-3xl font-bold text-gray-900">{selectedService.jobPostLimit}</p>
                                    <p className="text-xs text-gray-600 mt-1">tin đăng tuyển dụng</p>
                                </div>
                                <div className="bg-gradient-to-br from-yellow-50 to-orange-50 p-5 rounded-xl border-2 border-yellow-200">
                                    <div className="flex items-center gap-3 mb-2">
                                        <div className="bg-yellow-500 p-2 rounded-lg">
                                            <Star size={20} className="text-white" />
                                        </div>
                                        <span className="text-sm font-medium text-gray-700">Tin nổi bật</span>
                                    </div>
                                    <p className="text-3xl font-bold text-gray-900">{selectedService.highlightJobLimit}</p>
                                    <p className="text-xs text-gray-600 mt-1">tin tuyển dụng nổi bật</p>
                                </div>
                            </div>

                            {/* Description */}
                            <div className="bg-gray-50 rounded-xl p-5 border border-gray-200">
                                <h5 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                                    <FileText size={20} className="text-blue-600" />
                                    Mô tả chi tiết
                                </h5>
                                <p className="text-gray-700 leading-relaxed">{selectedService.description}</p>
                            </div>

                            {/* Features */}
                            <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl p-5 border-2 border-blue-200">
                                <h5 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
                                    <Zap size={20} className="text-blue-600" />
                                    Tính năng nổi bật
                                </h5>
                                <ul className="space-y-3">
                                    {selectedService.features.map((feature, index) => (
                                        <li key={index} className="flex items-start gap-3">
                                            <div className="bg-green-500 p-1.5 rounded-full mt-0.5 flex-shrink-0">
                                                <Check size={16} className="text-white" />
                                            </div>
                                            <span className="text-gray-700 flex-1">{feature}</span>
                                        </li>
                                    ))}
                                </ul>
                            </div>

                            {/* Additional Info */}
                            <div className="grid grid-cols-2 gap-4 pt-4 border-t border-gray-200">
                                <div className="text-center">
                                    <p className="text-gray-500 text-sm mb-1">Số đơn hàng</p>
                                    <p className="text-2xl font-bold text-gray-900">{selectedService.orders}</p>
                                </div>
                                <div className="text-center">
                                    <p className="text-gray-500 text-sm mb-1">Doanh thu</p>
                                    <p className="text-2xl font-bold text-purple-600">
                                        {formatCurrency(selectedService.price * selectedService.orders)}
                                    </p>
                                </div>
                            </div>

                            {/* Actions */}
                            <div className="flex gap-3 pt-4">
                                <button
                                    onClick={() => {
                                        setShowDetailModal(false);
                                        handleEditService(selectedService);
                                    }}
                                    className="flex-1 px-4 py-3 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-xl hover:from-green-700 hover:to-emerald-700 font-medium transition-all shadow-lg hover:shadow-xl flex items-center justify-center gap-2"
                                >
                                    <Edit2 size={20} />
                                    Chỉnh sửa
                                </button>
                                <button
                                    onClick={() => setShowDetailModal(false)}
                                    className="flex-1 px-4 py-3 bg-gray-100 text-gray-700 rounded-xl hover:bg-gray-200 font-medium transition-colors"
                                >
                                    Đóng
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            <style jsx>{`
                @keyframes fadeIn {
                    from {
                        opacity: 0;
                    }
                    to {
                        opacity: 1;
                    }
                }

                @keyframes slideUp {
                    from {
                        transform: translateY(20px);
                        opacity: 0;
                    }
                    to {
                        transform: translateY(0);
                        opacity: 1;
                    }
                }

                .animate-fadeIn {
                    animation: fadeIn 0.2s ease-out;
                }

                .animate-slideUp {
                    animation: slideUp 0.3s ease-out;
                }

                .line-clamp-1 {
                    overflow: hidden;
                    display: -webkit-box;
                    -webkit-line-clamp: 1;
                    -webkit-box-orient: vertical;
                }

                .line-clamp-2 {
                    overflow: hidden;
                    display: -webkit-box;
                    -webkit-line-clamp: 2;
                    -webkit-box-orient: vertical;
                }
            `}</style>
        </div>
    );
}