export default function Page() {
  return <div>Dashboard content here</div>;
}
