export const AUTH_ROUTES = {
    LOGIN: "/login",
    LOGOUT: "/logout",
    ACCOUNT: "/account",
    REGISTER: "/register"
}