import axiosClient from "./axiosClient";

export const candidateSubscriptionService = {
  // ========== PACKAGE MANAGEMENT ==========

  // Lấy danh sách tất cả các gói của ứng viên
  getAllPackages: async () => {
    const response = await axiosClient.get("/candidate-packages");
    return response;
  },

  // Lấy chi tiết gói theo ID
  getPackageById: async (packageId) => {
    const response = await axiosClient.get(`/candidate-packages/${packageId}`);
    return response;
  },

  // Tạo gói dịch vụ mới (chỉ admin)
  createPackage: async (data) => {
    const response = await axiosClient.post("/candidate-packages", data);
    return response;
  },

  // ========== SUBSCRIPTION MANAGEMENT ==========

  // Mua gói dịch vụ
  purchasePackage: async (candidateId, packageId) => {
    const response = await axiosClient.post(
      "/candidate-subscriptions/purchase",
      { packageId },
      { params: { candidateId } }
    );
    return response;
  },

  // Lấy subscription hiện tại (active)
  getActiveSubscription: async (candidateId) => {
    const response = await axiosClient.get(
      `/candidate-subscriptions/active/${candidateId}`
    );
    return response;
  },

  // Lấy lịch sử subscription
  getSubscriptionHistory: async (candidateId) => {
    const response = await axiosClient.get(
      `/candidate-subscriptions/history/${candidateId}`
    );
    return response;
  },

  // Lấy thông tin sử dụng (usage tracking)
  checkUsage: async (candidateId) => {
    const response = await axiosClient.get(
      `/candidate-subscriptions/usage/${candidateId}`
    );
    return response;
  },

  // ========== UPGRADE PACKAGE ==========

  // Tính toán chi phí upgrade
  calculateUpgrade: async (candidateId, newPackageId) => {
    const response = await axiosClient.get(
      "/candidate-subscriptions/calculate-upgrade",
      { params: { candidateId, newPackageId } }
    );
    return response;
  },

  // Nâng cấp gói dịch vụ
  upgradePackage: async (candidateId, newPackageId) => {
    const response = await axiosClient.post(
      "/candidate-subscriptions/upgrade",
      { newPackageId },
      { params: { candidateId } }
    );
    return response;
  },

  // ========== ADD-ON MANAGEMENT ==========

  // Lấy danh sách add-on
  getAddOns: async () => {
    const response = await axiosClient.get("/candidate-addons");
    return response;
  },

  // Mua add-on
  purchaseAddOn: async (candidateId, addOnId) => {
    const response = await axiosClient.post(
      "/candidate-subscriptions/purchase-addon",
      { addOnId },
      { params: { candidateId } }
    );
    return response;
  },

  // ========== USAGE TRACKING ==========

  // Sử dụng lần ứng tuyển (job apply)
  useJobApply: async (candidateId) => {
    const response = await axiosClient.post(
      "/candidate-subscriptions/use-apply",
      {},
      { params: { candidateId } }
    );
    return response;
  },

  // Sử dụng highlight profile
  useHighlightProfile: async (candidateId) => {
    const response = await axiosClient.post(
      "/candidate-subscriptions/use-highlight",
      {},
      { params: { candidateId } }
    );
    return response;
  },
};