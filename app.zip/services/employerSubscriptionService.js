import { axiosClient } from "../utils/axiosClient";

export const employerSubscriptionService = {
  // ========== PACKAGE MANAGEMENT ==========

  // Lấy danh sách tất cả các gói của nhà tuyển dụng
  getAllPackages: async () => {
    const response = await axiosClient.get("/employer-packages");
    return response;
  },

  // Lấy chi tiết gói theo ID
  getPackageById: async (packageId) => {
    const response = await axiosClient.get(`/employer-packages/${packageId}`);
    return response;
  },

  // Tạo gói dịch vụ mới (chỉ admin)
  createPackage: async (data) => {
    const response = await axiosClient.post("/employer-packages", data);
    return response;
  },

  // ========== SUBSCRIPTION MANAGEMENT ==========

  // Mua gói dịch vụ
  purchasePackage: async (employerId, packageId) => {
    const response = await axiosClient.post(
      "/employer-subscriptions/purchase",
      { packageId },
      { params: { employerId } }
    );
    return response;
  },

  // Lấy subscription hiện tại (active)
  getActiveSubscription: async (employerId) => {
    const response = await axiosClient.get(
      `/employer-subscriptions/active/${employerId}`
    );
    return response;
  },

  // Lấy lịch sử subscription
  getSubscriptionHistory: async (employerId) => {
    const response = await axiosClient.get(
      `/employer-subscriptions/history/${employerId}`
    );
    return response;
  },

  // Lấy thông tin sử dụng (usage tracking)
  checkUsage: async (employerId) => {
    const response = await axiosClient.get(
      `/employer-subscriptions/usage/${employerId}`
    );
    return response;
  },

  // ========== UPGRADE PACKAGE ==========

  // Tính toán chi phí upgrade
  calculateUpgrade: async (employerId, newPackageId) => {
    const response = await axiosClient.get(
      "/employer-subscriptions/calculate-upgrade",
      { params: { employerId, newPackageId } }
    );
    return response;
  },

  // Nâng cấp gói dịch vụ
  upgradePackage: async (employerId, newPackageId) => {
    const response = await axiosClient.post(
      "/employer-subscriptions/upgrade",
      { newPackageId },
      { params: { employerId } }
    );
    return response;
  },

  // ========== ADD-ON MANAGEMENT ==========

  // Lấy danh sách add-on
  getAddOns: async () => {
    const response = await axiosClient.get("/employer-addons");
    return response;
  },

  // Tạo add-on mới (chỉ admin)
  createAddOn: async (data) => {
    const response = await axiosClient.post("/employer-addons", data);
    return response;
  },

  // Mua add-on
  purchaseAddOn: async (employerId, addOnId) => {
    const response = await axiosClient.post(
      "/employer-subscriptions/purchase-addon",
      { addOnId },
      { params: { employerId } }
    );
    return response;
  },

  // ========== USAGE TRACKING ==========

  // Sử dụng job post
  useJobPost: async (employerId) => {
    const response = await axiosClient.post(
      "/employer-subscriptions/use-job-post",
      {},
      { params: { employerId } }
    );
    return response;
  },

  // Sử dụng highlight
  useHighlight: async (employerId) => {
    const response = await axiosClient.post(
      "/employer-subscriptions/use-highlight",
      {},
      { params: { employerId } }
    );
    return response;
  },

  // Lấy danh sách add-on đang sử dụng
  getActiveAddOns: async (employerId) => {
    const response = await axiosClient.get(
      `/employer-subscriptions/active-addons/${employerId}`
    );
    return response;
  },
};