"use client";
import Link from "next/link";
import jobs from "../../../data/job-featured";
import Image from "next/image";
import { useEffect, useState } from "react";
import { getRelatedJobs } from "@/services/job-feature.service";
import { formatJobResults } from "@/utils/convert-function";

const RelatedJobs2 = ({ id, industry, country, city }) => {
  // =================================== States ===========================/
  const [relatedJobs, setRelatedJobs] = useState([]);

  useEffect(() => {
    if (id) {
      fetchRelatedJobs(id, industry, country, city);
    }
  }, [industry, country, city]);
  // =================================== Fetch Function ===========================/
  const fetchRelatedJobs = async (id, industry, country, city) => {
    try {
      const res = await getRelatedJobs({ id, industry, country, city });
      const format = res.results ? formatJobResults(res.results) : [];
      console.log("related job format: ", format);
      setRelatedJobs(format || []);
    } catch (error) {}
  };
  // =================================== Handle Function ===========================/

  // =================================== UI ===========================/
  return (
    <>
      {relatedJobs.length === 0 ? (
        <div className="text-center text-gray-500 py-10">
          <p className="text-xl font-semibold">
            😥 Không tìm thấy công việc liên quan
          </p>
        </div>
      ) : (
        <div className="row">
          {relatedJobs.map((item) => (
            <div
              className="job-block-four col-xl-3 col-lg-4 col-md-6 col-sm-12"
              key={item.id}
            >
              <div className="inner-box shadow rounded p-3 bg-white">
                {item.jobType ? (
                  <ul className="job-other-info">
                    {item.jobType?.map((val, i) => (
                      <li key={i} className={`${val.styleClass}`}>
                        {val.type}
                      </li>
                    ))}
                  </ul>
                ) : null}
                <span className="company-logo mb-2 block">
                  <Image
                    src={`${process.env.NEXT_PUBLIC_API_BACKEND_URL_IMAGE_COMPANY}/${item?.logo}`}
                    alt="featured job"
                    fill
                    className="rounded-full object-cover"
                  />
                </span>
                <span className="company-name text-gray-600 text-sm block">
                  {item?.company?.name || "Công ty không xác định"}
                </span>
                <h4 className="text-lg font-semibold my-1">
                  <Link href={`/job-single-v3/${item.id}`}>
                    {item.jobTitle}
                  </Link>
                </h4>
                <div className="location text-sm text-gray-500">
                  <span className="icon flaticon-map-locator mr-1"></span>
                  {item.location}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </>
  );
};

export default RelatedJobs2;
