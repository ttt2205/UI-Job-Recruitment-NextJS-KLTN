module.exports = [
  { id: 1, img: "/images/resource/employers-single-1.png" },
  { id: 2, img: "/images/resource/employers-single-2.png" },
  { id: 3, img: "/images/resource/employers-single-3.png" },
  { id: 4, img: "/images/resource/employers-single-4.png" },
];
