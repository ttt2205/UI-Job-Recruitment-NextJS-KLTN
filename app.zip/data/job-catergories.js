module.exports = [
  {
    id: 1,
    icon: "flaticon-money-1",
    catTitle: "Accounting / Finance",
    jobNumber: "2",
  },
  {
    id: 2,
    icon: "flaticon-promotion",
    catTitle: "Marketing",
    jobNumber: "86",
  },
  { id: 3, icon: "flaticon-vector", catTitle: "Design", jobNumber: "43" },
  {
    id: 4,
    icon: "flaticon-web-programming",
    catTitle: "Development",
    jobNumber: "12",
  },
  {
    id: 5,
    icon: "flaticon-headhunting",
    catTitle: "Human Resource",
    jobNumber: "55",
  },
  {
    id: 6,
    icon: "flaticon-rocket-ship",
    catTitle: "Automotive Jobs",
    jobNumber: "2",
  },
  {
    id: 7,
    icon: "flaticon-money-1",
    catTitle: "Customer Service",
    jobNumber: "2",
  },
  {
    id: 8,
    icon: "flaticon-first-aid-kit-1",
    catTitle: "Health and Care",
    jobNumber: "25",
  },
  {
    id: 9,
    icon: "flaticon-car",
    catTitle: "Project Management",
    jobNumber: "92",
  },
];
