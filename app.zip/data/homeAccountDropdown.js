module.exports = [
    {
        id: 1,
        name: "Logout",
        icon: "la-sign-out",
        routePath: null,
        active: "",
        key: "logout"
    },
]